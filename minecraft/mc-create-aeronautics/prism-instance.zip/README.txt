Create Aeronautics / Prism Launcher

Prism Launcher: Add Instance > Import from zip. Use Java 21.
MODs download before each launch. Internet access is required.
This ZIP contains no game MODs, saves, accounts or private settings.

Pack: https://yuutaro.github.io/homeserver-gameserver-1/minecraft/mc-create-aeronautics/pack.toml
Includes packwiz-installer-bootstrap v0.0.3 (MIT):
https://github.com/packwiz/packwiz-installer-bootstrap
Source asset: https://github.com/packwiz/packwiz-installer-bootstrap/releases/download/v0.0.3/packwiz-installer-bootstrap.jar
